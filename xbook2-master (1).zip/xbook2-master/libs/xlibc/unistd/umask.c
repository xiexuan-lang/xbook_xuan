#include <sys/stat.h>

mode_t umask(mode_t mask)
{
    /* FIXME: set mask in kernel */
    return 0;
}