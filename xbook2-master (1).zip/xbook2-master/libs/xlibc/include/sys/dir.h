#ifndef _SYS_DIR_H
#define _SYS_DIR_H

#ifdef __cplusplus
extern "C" {
#endif

void build_path(const char *path, char *out_path);

#ifdef __cplusplus
}
#endif

#endif   /* _SYS_DIR_H */