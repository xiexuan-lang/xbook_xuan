#ifndef _SYS_PARAM_H
#define _SYS_PARAM_H

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif  /* _SYS_PARAM_H */
