#ifndef _XLIBC_WCHAR_H
#define _XLIBC_WCHAR_H

#ifdef __cplusplus
extern "C" {
#endif

#ifndef _WCHAR_T_DEFINED   
typedef unsigned short wchar_t;   
#define _WCHAR_T_DEFINED   
#endif  

#ifdef __cplusplus
}
#endif

#endif  /* _XLIBC_WCHAR_H */
