#ifndef _LIB_STRINGS_H
#define _LIB_STRINGS_H

#ifdef __cplusplus
extern "C" {
#endif


#ifdef __cplusplus
}
#endif

#endif  /* _LIB_STRINGS_H */

