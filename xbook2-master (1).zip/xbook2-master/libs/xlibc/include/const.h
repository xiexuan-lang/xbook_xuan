#ifndef __XLIBC_CONST_H__
#define __XLIBC_CONST_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "arch/const.h"

#ifdef __cplusplus
}
#endif

#endif /* __XLIBC_CONST_H__ */
