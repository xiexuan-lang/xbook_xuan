/*
 * xlibc/stdio/system.c
 */

#include <stdio.h>

int system(const char * cmd)
{

	return 0;
    //return shell_system(cmd);
}
