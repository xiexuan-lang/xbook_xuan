#include <stdlib.h>

long int labs(long int const i)
{
	return i > 0 ? i : -i;
}
