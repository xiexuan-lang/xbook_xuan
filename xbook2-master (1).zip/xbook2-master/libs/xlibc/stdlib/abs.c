#include <stdlib.h>

int abs(int const i)
{
	return i > 0 ? i : -i;
}
