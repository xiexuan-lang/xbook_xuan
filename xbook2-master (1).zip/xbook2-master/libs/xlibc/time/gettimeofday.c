/*
 * libc/time/gettimeofday.c
 */

