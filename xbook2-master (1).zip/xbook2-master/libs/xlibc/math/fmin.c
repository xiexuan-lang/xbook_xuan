
#include <math.h>

double fmin(double x, double y) {
    return (double) (x < y ? x : y);
}
