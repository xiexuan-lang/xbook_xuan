
#include <math.h>

float fminf(float x, float y) {
    return (float) (x < y ? x : y);
}
