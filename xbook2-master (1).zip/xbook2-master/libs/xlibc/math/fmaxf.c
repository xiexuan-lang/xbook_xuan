
#include <math.h>

float fmaxf(float x, float y) {
    return (float) (x > y ? x : y);
}
