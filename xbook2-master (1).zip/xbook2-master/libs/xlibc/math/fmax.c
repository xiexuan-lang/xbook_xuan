
#include <math.h>

double fmax(double x, double y) {
    return (double) (x > y ? x : y);
}
