#include <termios.h>
#include <string.h>

int tcsetattr(int fildes,int optional_actions,struct termios *termios_p)
{
    // TODO: set attr
    return 0;
}
 