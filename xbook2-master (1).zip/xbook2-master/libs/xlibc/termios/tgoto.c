#include <termios.h>
#include <stddef.h>

char *tgoto(const char *cap, int col, int row)
{
    /* FIXME: set cursor */
    return NULL;
}
