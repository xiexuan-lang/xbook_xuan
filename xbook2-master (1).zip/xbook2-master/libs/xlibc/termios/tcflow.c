#include <termios.h>

int tcflow(int fildes,int action)
{
    /* FIXME: set flow in tty */
    return -1;
} 